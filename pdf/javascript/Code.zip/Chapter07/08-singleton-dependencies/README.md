# 08-singleton-dependencies

This example shows how to wire dependencies using the singleton pattern

## Dependencies

Install all necessary dependencies with:

```shell script
npm install
```

## Run

To run the example:

```shell script
node import-posts.js
node index.js
```
