# 05-builder-url-builder

This example demonstrate how to use the builder pattern to simplify the creation of Url object.

## Run

To run the example launch:

```bash
node index.js
```

