# 02-factory-dynamic-class

This sample demonstrates how to create a Factory function that can resolve the class of the object to create at runtime.

## Run

To run the example launch:

```bash
node index.js
```

