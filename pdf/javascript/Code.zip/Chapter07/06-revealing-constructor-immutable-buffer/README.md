# 06-revealing-constructor-immutable-buffer

This example demonstrate how to use the revealing constructor pattern to implement an immutable buffer.

## Run

To run the example launch:

```bash
node index.js
```

