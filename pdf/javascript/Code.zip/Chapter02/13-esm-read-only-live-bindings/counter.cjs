exports.count = 0
exports.increment = function () {
  exports.count++
}
