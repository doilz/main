import { Module } from 'module'

console.log(Module)
