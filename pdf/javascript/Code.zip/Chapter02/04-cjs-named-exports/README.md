# 04-cjs-named-exports

This sample demonstrates how to use named exports with CommonJS

## Run

```bash
node main
```