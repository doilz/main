# 10-esm-default

This sample demonstrates the default import/export syntax of ESM modules

## Run

```bash
node main.js
node showDefault.js
```