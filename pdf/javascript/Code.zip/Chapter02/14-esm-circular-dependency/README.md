# 13-esm-circular-dependency

This sample demonstrates that ESM can effectively resolve circular dependencies.

## Run

```bash
node main.js
```