import * as aModule from './a.js'
export let loaded = false
export const a = aModule
loaded = true
