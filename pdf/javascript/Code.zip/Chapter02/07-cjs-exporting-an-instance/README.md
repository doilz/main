# 07-cjs-exporting-an-instance

This sample demonstrates how to export an instance with CommonJS

## Run

```bash
node main
```