import mylog, { info } from './logger.js'

mylog('Hello')
info('World')
