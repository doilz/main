require('./logger').customMessage = function () {
  console.log('This is a new functionality')
}
