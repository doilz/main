require('./patcher')
const logger = require('./logger')

logger.customMessage()
