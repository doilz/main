# 08-cjs-monkey-patching

This sample demonstrates how to monkey patch an existing module with CommonJS

## Run

```bash
node main
```