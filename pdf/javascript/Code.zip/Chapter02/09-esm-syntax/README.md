# 09-esm-syntax

This sample demonstrates the basic syntax of ESM modules

## Run

```bash
node main1.js
node main2.js
node main3.js
node main4.js
node main5.js
```