export const HELLO = 'Γεια σου κόσμε'
