export const HELLO = 'Ciao mondo'
