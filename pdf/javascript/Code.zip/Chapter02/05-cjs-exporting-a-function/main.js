const logger = require('./logger')

logger('This is an informational message')
logger.verbose('This is a verbose message')
