# 01-revealing-module-pattern

This example demonstrates the revealing module pattern.

## Run

To run the example launch:

```bash
node index.js
```