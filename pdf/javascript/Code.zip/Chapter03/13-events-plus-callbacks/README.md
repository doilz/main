# 13-events-plus-callbacks

This sample demonstrates how the `glob` package, combines callbacks
and the EventEmitter.

## Run

Install the necessary dependencies with `npm install` and then run:

```bash
node index.js
```
