# 08-uncaught-errors

This example demonstrates how uncaught errors will cause the application to exit. It also shows how to catch those errors just before the application exits.

## Run

To run the example launch:

```bash
node index.js
```
