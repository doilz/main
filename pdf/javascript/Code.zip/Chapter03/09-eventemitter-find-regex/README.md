# 09-eventemitter-find-pattern

This sample demonstrates how to create and use an EventEmitter. The `findRegex` function returns an EventEmitter that produces an event when a string matching the provided regular expression is found in one files passed as input.

## Run

To run the example launch:

```bash
node index.js
```
