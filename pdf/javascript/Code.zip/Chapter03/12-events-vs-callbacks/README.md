# 12-events-vs-callbacks

This sample demonstrates how it's possible to use an event emitter to return a result asynchronously instead of using a callback.

## Run

To run the example launch:

```bash
node index.js
```
