# 06-deferred-execution

This example demonstrates how to fix Zalgo by deferring any synchronous callback invocation.

## Run

To run the example launch:

```bash
node index.js
```
