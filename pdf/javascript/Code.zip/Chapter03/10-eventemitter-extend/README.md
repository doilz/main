# 10-eventemitter-extend

This sample demonstrates how to extend an EventEmitter.

## Run

To run the example launch:

```bash
node index.js
```
