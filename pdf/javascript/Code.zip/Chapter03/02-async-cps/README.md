# 02-async-cps

This example demonstrates asynchronous continuous passing with callbacks.

## Run

To run the example launch:

```bash
node index
```
