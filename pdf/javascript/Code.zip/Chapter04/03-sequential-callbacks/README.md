# 03-sequential-callbacks

Simple example that demonstrates sequential tasks using callbacks

## Run

Run:

```bash
node test.js
```
