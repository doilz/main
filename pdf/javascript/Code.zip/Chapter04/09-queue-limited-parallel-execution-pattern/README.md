# 09-queue-limited-parallel-execution-pattern

Simple example that demonstrates the callback limited parallel execution pattern using a Queue

## Run

Run:

```bash
node test.js
```
