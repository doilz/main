# 18-sequential-execution

This examples shows how to create a sequential execution flow using streams.


## Run

To run the example:

```bash
node concat.js <destination> <source1> <source2> <source3> ...
```
