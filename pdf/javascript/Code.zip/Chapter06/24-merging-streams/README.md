# 24-merging-streams

This examples shows how to merge streams.


## Dependencies

Install all necessary dependencies with:

```bash
npm install
```


## Run

To run the example:

```bash
node merge-lines.js <destination> <source1> <source2> <source3> ...
```
