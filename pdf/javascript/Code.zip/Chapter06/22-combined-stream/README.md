# 22-combined-stream

This examples shows how to create a combined stream using `pumpify`.


## Dependencies

Install all necessary dependencies with:

```bash
npm install
```


## Run

To run the example:

```bash
node archive.js <a_password> <path/to/a/file>
```
