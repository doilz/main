# 23-forking-streams

This examples shows how to fork a stream.


## Run

To run the example:

```bash
node generate-hashes.js <path/to/a/file>
```
