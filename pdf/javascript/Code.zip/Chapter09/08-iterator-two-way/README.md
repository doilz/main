# 08-iterator-two-way

This sample demonstrates how to pass values back to a generator.

## Run

To run the example launch:

```
node index.js
```

