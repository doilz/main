# 11-async-generator-check-url

This sample demonstrates how to use an async generator to implement an async iterator.

## Run

To run the example install its dependencies with `npm install`, then launch:

```
node index.js
```

