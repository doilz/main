# 03-template-multiformat-config

This sample demonstrates how to use the Template pattern to create different configuration managers supporting different file formats.

## Run

Install the necessary dependencies with `npm install` and then run:

```
node index.js
```

