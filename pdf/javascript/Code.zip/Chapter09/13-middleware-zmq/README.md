# 13-middleware-zmq

This sample demonstrates how to build a middleware infrastructure for ZMQ.

## Run

To run the example install its dependencies with `npm install`, then run the following commands in two different terminals:

```
node server.js
```

And then:

```
node client.js
```


