# 09-iterator-matrix-generator

This sample demonstrates how to use a generator in place of a standard iterator.

## Run

To run the example launch:

```
node index.js
```

