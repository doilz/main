# 12-promises-recursion-leak

This sample demonstrate how infinite chains of unresolved Promises can lead to memory leaks.

## Run

To run the example launch:

```bash
node index.js
```

