# 07-asyncawait-errors

This sample demonstrates how to deal with errors in async functions.

## Run

To run the example launch:

```bash
node index.js
```
