# 06-asyncawait-delay

This sample gives an introduction on the async/await construct.

## Run

To run the example launch:

```bash
node index.js
```
