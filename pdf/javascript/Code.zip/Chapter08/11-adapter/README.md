# 11-adapter

This examples shows how to use the adapter pattern to build an FS-like interface that writes to level db instead


## Dependencies

Install all necessary dependencies with:

```bash
npm install
```


## Run

To run the example:

```bash
node index.js
```
