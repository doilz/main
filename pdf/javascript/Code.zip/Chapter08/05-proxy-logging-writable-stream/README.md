# 05-proxy-logging-writable-stream

This example demonstrate how to create a proxies that enhances a Writable stream instance adding logging functionality

## Run

To run the example launch:

```bash
node index.js
```
