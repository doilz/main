# 06-proxy-reactive

This example demonstrate how to use reactive programming using the ES2015 Proxy

## Run

To run the example launch:

```bash
node index.js
```
