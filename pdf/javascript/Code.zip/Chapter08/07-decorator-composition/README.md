# 07-decorator-composition

This example demonstrate how to implement a decorator using composition

## Run

To run the example launch:

```bash
node index.js
```
