# 04-proxy-es2015

This example demonstrate how to create proxies using the ES2015 Proxy helper

## Run

To run the example launch:

```bash
node safe-calculator.js
```

Or

```bash
node even-numbers.js
```
