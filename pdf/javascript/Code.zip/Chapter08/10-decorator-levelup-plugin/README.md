# 10-decorator-levelup-plugin

This examples shows how to use the decorator pattern to build a LevelUP plugin.


## Dependencies

Install all necessary dependencies with:

```bash
npm install
```


## Run

To run the example:

```bash
node index.js
```
